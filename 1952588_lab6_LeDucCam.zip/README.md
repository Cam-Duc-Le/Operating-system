type "make all" to compile
type "./mem" to test  (each case must go to mem.c end decomment some line for each case)

