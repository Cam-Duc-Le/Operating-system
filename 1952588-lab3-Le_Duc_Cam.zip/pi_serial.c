#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
int main (int argc , char **argv ){
  if(argc<2){
    printf("input a number !\n ");
    exit(0);
  } 
  char *num = argv[1];
  long total = (long)atoi(num);  
  clock_t start, end;
  start = clock();
  long inside = 0;
  float x,y;
  for (int i = 0; i < total; i++) {
    x = ((float)rand()/RAND_MAX)  ;
    y =((float)rand()/RAND_MAX)  ;
    if( (x*x + y*y) <=1) inside++;
  }
  double pi = 4*((double)inside/total);
  end = clock();
  double cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
  printf("pi_serial = %f \n",pi);
  printf("run time: %f sec\n",cpu_time_used);
  return 0;
}


