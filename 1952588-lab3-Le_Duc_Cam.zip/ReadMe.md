Type 'make all' to compile all three .c program

To execute pi_serial.c and pi_multi-thread.c of problem 1, type below commands (you can change the number of points):
    ./pi_serial 10000000
    ./pi_multi-thread 10000000

To execute code.c of problem 2, type follow commands to see thread id in ascending order :
    ./code

Finally type follow command to remove all object: 
    make clean