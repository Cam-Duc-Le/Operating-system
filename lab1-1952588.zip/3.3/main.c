#include <stdio.h>
#include <stdlib.h>
#include "factorial.h"
#include "readline.h"
int main( int argc , char *argv [ ]) {
  if(argc < 2){
    printf("input filename! \n");
  }
  else{
    char s[]="exit";
    stdin = fopen(argv[1],"r");
    char *line = (char *)malloc(50);
    while(!feof(stdin)){
      if(read_line(line) == 1){
        int num = atoi(line);
				printf("%d\n", factorial(num));
      }
      else{
        printf("-1\n");
      }
    }
    free(line);
    fclose(stdin);
  }
  return 0;
}