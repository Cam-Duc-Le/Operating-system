#include "readline.h"
#include <ctype.h>
#include <stdio.h>
#include <stdbool.h>
int read_line ( char *str ){
  if (feof(stdin) || ferror(stdin) || !str) return -1;
	int index = 0;
	bool flag = true;
	while (index < 50){
		char character = fgetc(stdin);
		if (character == EOF) return -1;
		if (character == '\n') break;
		if (!isdigit(character)){
			flag = false;
		}
		str[index] = character;
    index++; 
	}
	str[index] = '\0';
	if (flag && index > 0 && index < 50) return 1;
	return 0;
}