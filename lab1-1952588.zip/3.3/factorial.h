// f a c t o r i a l . h
#ifndef FACTORIAL_H
#define FACTORIAL_H
int factorial ( const int aNumber ) ;
#endif