#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <assert.h>
#include <time.h>

static volatile long g_count = 0;
long inum = 0;
pthread_mutex_t lock ;
void *cal(void* arg){
  float x,y;
  unsigned int seed = time(NULL);
  
  for (int i = 0; i < inum; i++){
    x = ((float)rand_r(&seed)/RAND_MAX)*2-1  ;
    y =((float)rand_r(&seed)/RAND_MAX)*2-1   ;
    
    if( (x*x + y*y) <=1){
      pthread_mutex_lock(&lock ) ;
      g_count++ ;
      pthread_mutex_unlock(&lock ) ;
    }
  }
  
  pthread_exit(NULL);
  return NULL;
}
int main (int argc , char **argv ){
  if(argc<2){
    printf("input a number !\n ");
    exit(0);
  } 
  char *num = argv[1];
  long total = (long)atoi(num);  
  inum = total/10;
  clock_t start, end;
  pthread_t tid[10];
  start = clock();
  for (int i = 0; i < 10; i++){
    pthread_create(&tid[i],NULL,cal,NULL);
  };   
  for(int i=0;i<10;i++){
    pthread_join(tid[i], NULL);
  } 
  long double pi = 4*((long double)g_count/total);
  end = clock();
  double cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
  printf("pi_multi-thread = %Lf \n",pi);
  printf("run time: %f sec \n",cpu_time_used);
  pthread_exit(NULL);
  return 0;
}



