#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/wait.h>
void create_EF(pid_t c,pid_t e){
  pid_t f,i;
  e = fork();
  if(e == -1) exit(1);
  else if(e == 0){// process e
    printf("process e ID: %d ,its parent'id: %d\n",getpid(),getppid());
    kill(getpid(),SIGSTOP);
    i = fork();
    if(i == -1) exit(1);
    else if(i == 0){ //process i
      printf("process i ID: %d,  its parent'id: %d\n",getpid(),getppid());
      kill(getpid(),SIGSTOP);
    }
    else{
      waitpid(i, NULL, WUNTRACED);
    }
  }
  else{//continue b
    waitpid(e, NULL, WUNTRACED);
    f = fork();
    if(f == -1) exit(1);
    else if(f == 0){ //process f
      printf("process f ID: %d,  its parent'id: %d\n",getpid(),getppid());
      kill(getpid(),SIGSTOP);
    }
    else{
        waitpid(f, NULL, WUNTRACED);
        kill(c,SIGCONT);
        waitpid(c, NULL, WUNTRACED);
        kill(e,SIGCONT);
    }
  }
}


int main( int argc , char *argv[]) {
    printf("process a(current root) ID: %d \n",getpid());
    pid_t b,c,d,g,e;
    b = fork();
    if(b == -1) exit(1);
    else if(b == 0){ //process b
      printf("process b ID: %d , its parent'id: %d \n",getpid(),getppid());
      kill(getpid(),SIGSTOP);// force process b to temporary stop
      create_EF(c,e);
      kill(getpid(),SIGSTOP);
    }
    else{// continue process a
      waitpid(b, NULL, WUNTRACED);
      c = fork();
      if(c == -1) exit(1);
      else if(c == 0){ //process c
        printf("process c ID: %d,  its parent'id: %d \n",getpid(),getppid());
        kill(getpid(),SIGSTOP);

        g = fork();
        if(g == -1) exit(1);
        else if(g == 0){ //process g
          printf("process g ID: %d,  its parent'id: %d\n",getpid(),getppid());
          kill(getpid(),SIGSTOP);
        }
        else{ // continue process e
          waitpid(g, NULL, WUNTRACED);
          kill(e,SIGCONT);
        }
      }
      else{// continue process a
        waitpid(c, NULL,WUNTRACED);
        d = fork();
        if(d == -1) exit(1);
        else if(d == 0){ //process b
          printf("process d ID: %d, its parent'id: %d\n",getpid(),getppid());
          kill(getpid(),SIGSTOP);
        }
        else{
          waitpid(d, NULL, WUNTRACED);
          kill(b,SIGCONT);
          waitpid(b, NULL, WUNTRACED);
          kill(c,SIGCONT);
          waitpid(c, NULL, WUNTRACED);
        }
      }

    }


 return 0;
}