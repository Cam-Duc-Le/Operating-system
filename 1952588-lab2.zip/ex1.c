#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/wait.h>
int count_div(int *arr, int len, int n){
    int count = 0;
    for(int i=0; i<len; i++){
      if (arr[i] % n == 0) count++;
    }
    return count;
}

int main( int argc , char *argv[] ) {
  if(argc < 2){
    printf("input filename! \n");
  }
  else{
    int number;
    int len = 0;
    stdin = fopen(argv[1],"r");
    while (fscanf(stdin, "%d", &number) != EOF){
      len++;
    }
    int *arr = malloc(len * sizeof(int));
    fseek(stdin, 0, SEEK_SET); //input array
    for(int i=0;i<len;i++)
      fscanf(stdin, "%d", &arr[i]);
    
    
    pid_t child;
    child = fork();
    if(child == -1)  exit(1);
    else if(child == 0){ // child process
      waitpid(getppid(),NULL,WUNTRACED);
      printf("Child: %d\n",count_div(arr,len,3));
    } 
    else // parent proccess
      printf("Parent: %d\n",count_div(arr,len,2));
    
    free(arr);
    fclose(stdin);
  }

return 0;
}